# Image Filtering using CUDA

This project applies a simple blur filter to an input image using CUDA.

## Building

To build the project, run the following command:
```bash
make clean build