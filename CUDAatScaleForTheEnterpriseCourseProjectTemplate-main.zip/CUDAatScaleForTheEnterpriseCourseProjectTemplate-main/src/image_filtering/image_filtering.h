// image_filtering.h

#ifndef IMAGE_FILTERING_H
#define IMAGE_FILTERING_H

void applyFilter(unsigned char* inputImage, unsigned char* outputImage, int width, int height);

#endif  // IMAGE_FILTERING_H